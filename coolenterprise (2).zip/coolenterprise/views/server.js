const express = require("express");
const bodyParser = require("body-parser");

const app = expresss();

app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(bodyParser.json());

app route("/ajax")
.get(function(req, res){
     res.render('ajax', {message: "RECEIVED"});
     })
     .post(function(req, res){
     	res.send({response: req.body.message});

     });


     app.listen(process.env.PORT || 3000);