$(document).ready(function(){
$("#changeMessage").on("submit", function(event){
  event.preventDefault();
  let value = $("value-name").val();


  $.ajax({
  	url:"/ajax",
  	method: "POST,"
  	contentType: "application/json",
  	data: JSON.stringify({message: value}),
  	success: function(res){
  	    $("h1").html('message: ${res.response}');
  	}}
  	)}
  )}
)